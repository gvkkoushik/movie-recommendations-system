import time
import requests
import pandas as pd
import streamlit as st

TMDB_BASE = "https://api.themoviedb.org/3"

st.set_page_config(page_title="Telugu Movie Database", page_icon="🎬", layout="wide")
st.title("🎬 Telugu Movie Database")
st.write("Find Telugu-language movies with TMDB ratings, release dates, genres, and vote counts.")

st.info(
    "This app retrieves Telugu-language movies listed by TMDB. It cannot guarantee every Telugu film ever made, "
    "and it will not automatically include every Telugu-dubbed film originally made in another language."
)

with st.sidebar:
    st.header("TMDB API access")
    token = st.text_input(
        "TMDB API Read Access Token",
        type="password",
        help="Paste your own TMDB API Read Access Token. It is used only for requests from this app."
    )
    st.caption("Get a token from your TMDB account's API settings.")
    sort_label = st.selectbox(
        "Sort results by",
        ["Popularity (high to low)", "Rating (high to low)", "Release date (newest first)", "Title (A–Z)"]
    )
    min_votes = st.number_input("Minimum vote count", min_value=0, max_value=100000, value=0, step=10)
    max_pages = st.slider("Pages to fetch", min_value=1, max_value=500, value=10,
                          help="Each page contains up to 20 movies. 500 pages can take a long time.")

sort_map = {
    "Popularity (high to low)": "popularity.desc",
    "Rating (high to low)": "vote_average.desc",
    "Release date (newest first)": "primary_release_date.desc",
    "Title (A–Z)": "title.asc",
}

@st.cache_data(ttl=1800, show_spinner=False)
def fetch_page(token_value, page_number, sort_by, minimum_votes):
    url = f"{TMDB_BASE}/discover/movie"
    headers = {
        "Authorization": f"Bearer {token_value}",
        "accept": "application/json",
    }
    params = {
        "include_adult": "false",
        "include_video": "false",
        "language": "en-US",
        "with_original_language": "te",
        "sort_by": sort_by,
        "vote_count.gte": int(minimum_votes),
        "page": int(page_number),
    }
    response = requests.get(url, headers=headers, params=params, timeout=30)
    if response.status_code == 401:
        raise ValueError("TMDB rejected the token. Check that you copied the API Read Access Token correctly.")
    response.raise_for_status()
    return response.json()

def get_genres(token_value):
    headers = {"Authorization": f"Bearer {token_value}", "accept": "application/json"}
    response = requests.get(f"{TMDB_BASE}/genre/movie/list",
                            headers=headers, params={"language": "en-US"}, timeout=30)
    response.raise_for_status()
    return {g["id"]: g["name"] for g in response.json().get("genres", [])}

if "telugu_movies" not in st.session_state:
    st.session_state.telugu_movies = None

if st.button("Fetch Telugu movies", type="primary", use_container_width=True):
    if not token.strip():
        st.error("Enter your TMDB API Read Access Token in the sidebar first.")
    else:
        records = []
        progress = st.progress(0, text="Connecting to TMDB…")
        try:
            genres = get_genres(token.strip())
            first = fetch_page(token.strip(), 1, sort_map[sort_label], min_votes)
            total_pages = min(int(first.get("total_pages", 1)), int(max_pages), 500)
            pages = [first]
            progress.progress(1 / max(total_pages, 1), text=f"Fetching page 1 of {total_pages}…")
            for page in range(2, total_pages + 1):
                pages.append(fetch_page(token.strip(), page, sort_map[sort_label], min_votes))
                progress.progress(page / total_pages, text=f"Fetching page {page} of {total_pages}…")
                time.sleep(0.05)
            for data in pages:
                for m in data.get("results", []):
                    poster = m.get("poster_path")
                    records.append({
                        "tmdb_id": m.get("id"),
                        "title": m.get("title", ""),
                        "original_title": m.get("original_title", ""),
                        "release_date": m.get("release_date", ""),
                        "year": (m.get("release_date") or "")[:4],
                        "rating_out_of_10": m.get("vote_average", 0),
                        "vote_count": m.get("vote_count", 0),
                        "genres": ", ".join(genres.get(g, str(g)) for g in m.get("genre_ids", [])),
                        "overview": m.get("overview", ""),
                        "poster_url": f"https://image.tmdb.org/t/p/w500{poster}" if poster else "",
                        "tmdb_url": f"https://www.themoviedb.org/movie/{m.get('id')}",
                        "original_language": m.get("original_language", ""),
                    })
            df = pd.DataFrame(records).drop_duplicates(subset=["tmdb_id"])
            st.session_state.telugu_movies = df
            progress.empty()
            st.success(f"Fetched {len(df):,} unique Telugu-language movies from TMDB.")
        except Exception as exc:
            progress.empty()
            st.error(f"Could not fetch movies: {exc}")

df = st.session_state.telugu_movies
if df is not None:
    col1, col2, col3 = st.columns(3)
    col1.metric("Movies fetched", f"{len(df):,}")
    col2.metric("Average TMDB rating", f"{df['rating_out_of_10'].mean():.2f}/10" if len(df) else "—")
    col3.metric("Movies with votes", f"{int((df['vote_count'] > 0).sum()):,}")

    query = st.text_input("Search by movie title")
    min_rating = st.slider("Minimum rating", 0.0, 10.0, 0.0, 0.5)
    view = df[df["rating_out_of_10"] >= min_rating]
    if query.strip():
        view = view[view["title"].str.contains(query.strip(), case=False, na=False) |
                    view["original_title"].str.contains(query.strip(), case=False, na=False)]
    st.dataframe(
        view[["title", "year", "genres", "rating_out_of_10", "vote_count", "release_date", "tmdb_url"]],
        use_container_width=True, hide_index=True
    )
    st.download_button(
        "Download movie data as CSV",
        data=view.to_csv(index=False).encode("utf-8-sig"),
        file_name="telugu_movies_ratings.csv",
        mime="text/csv",
        use_container_width=True
    )
    st.caption("Ratings and metadata are supplied by TMDB and can change over time.")
    st.markdown("Data source: [The Movie Database (TMDB)](https://www.themoviedb.org/). This product uses the TMDB API but is not endorsed or certified by TMDB.")
else:
    st.markdown("### How to use")
    st.markdown(
        "1. Create a TMDB account and request an API Read Access Token in your account's API settings.\n"
        "2. Paste the token into the sidebar.\n"
        "3. Choose how many pages to fetch. Each page contains up to 20 movies.\n"
        "4. Click **Fetch Telugu movies**.\n"
        "5. Search, filter by rating, and download the results as CSV."
    )
    st.warning("A large fetch may take several minutes. Start with 10 pages to test the app.")
