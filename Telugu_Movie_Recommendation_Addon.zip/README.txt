TELUGU MOVIE DATABASE ADD-ON
============================

This is a separate Streamlit app for fetching Telugu-language movie metadata and ratings from TMDB.
It is not a replacement for your existing app.py. Keep your current project files.

FILES
-----
- telugu_movies_app.py : Streamlit app
- requirements.txt     : Python dependencies
- README.txt           : these instructions

RUN IN PYCHARM (Windows)
------------------------
1. Extract this ZIP file.
2. Copy telugu_movies_app.py and requirements.txt into your
   Movie_Recommendations_System project folder.
3. Open the PyCharm Terminal and run:

   pip install -r requirements.txt

4. Get your TMDB API Read Access Token from:
   https://developer.themoviedb.org/docs/authentication-application

5. Run this command in the project terminal:

   streamlit run telugu_movies_app.py

6. Open the local address printed in the terminal (usually
   http://localhost:8501).
7. Paste your token in the app sidebar and click "Fetch Telugu movies".

IMPORTANT
---------
- This fetches movies whose original language is Telugu (language code te)
  and which are listed in TMDB. No source can guarantee literally every
  Telugu film ever released.
- Telugu-dubbed films originally made in other languages are not necessarily
  included by the Telugu original-language filter.
- Ratings/vote counts are TMDB user ratings, not IMDb ratings.
- You need an internet connection and your own TMDB API token.
- Start with 10 pages. Each page has up to 20 movies. You can increase the
  page limit up to 500 (up to 10,000 results for this query).
- Do not share your API token publicly.
- This is an add-on. It does not overwrite your existing app.py or CSV files.

TMDB attribution:
This product uses the TMDB API but is not endorsed or certified by TMDB.
https://www.themoviedb.org/
